sap.ui.define([
	"ZPUI_BCMM_COND/ZPUI_BCMM_COND/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	'sap/m/Dialog',
	'sap/m/Button',
	'sap/m/Text',
	"ZPUI_BCMM_COND/ZPUI_BCMM_COND/model/formatter"
], function(BaseController, JSONModel, Dialog, Button, Text, formatter) {
	"use strict";

	return BaseController.extend("ZPUI_BCMM_COND.ZPUI_BCMM_COND.controller.Transpo", {

		formatter: formatter,

		onInit: function() {
			// var oViewModel = new JSONModel({
			// 	busy: false,
			// 	delay: 0
			// });

			this.getRouter().getRoute("transpo").attachPatternMatched(this._onObjectMatched, this);
			this.getRouter().getRoute("backtranspo").attachPatternMatched(this.attTable, this);
			//this.setModel(oViewModel, "detailView");

			//this.getOwnerComponent().getModel().metadataLoaded().then(this._onMetadataLoaded.bind(this));
		},

		attTable: function() {
			var smartTable = this.getView().byId("smartTable");
			smartTable.rebindTable("e");

			sap.m.MessageToast.show("Registros inserido com sucesso");
		},

		_onObjectMatched: function(oEvent) {
			var Bukrs = oEvent.getParameter("arguments").Bukrs;
			var IdSolicitacao = oEvent.getParameter("arguments").IdSolicitacao;
			var WerksO = oEvent.getParameter("arguments").WerksO;
			var IdRota = oEvent.getParameter("arguments").IdRota;
			var NrTransp = oEvent.getParameter("arguments").NrTransp;

			this.getModel().metadataLoaded().then(function() {
				var sObjectPath = this.getModel().createKey("ZET_CBMM_CF_TRANSPSet", {
					Bukrs: Bukrs,
					WerksO: WerksO,
					IdSolicitacao: parseInt(IdSolicitacao),
					IdRota: parseInt(IdRota),
					NrTransp: NrTransp
				});
				this._bindView("/" + sObjectPath);
			}.bind(this));
		},

		atualizaTabela: function(oEvent) {
			var NrTransp = this.getView().byId("IdNrTransp").getValue();
			var IdRota = this.getView().byId("IdRota").getValue();
			var IdSolicitacao = this.getView().byId("IdSolicitacao").getValue();
			
			var filter01 = new sap.ui.model.Filter({path: "NrTransp", operator: "EQ", value1: NrTransp });
			var filter02 = new sap.ui.model.Filter({path: "IdRota", operator: "EQ", value1: IdRota });
			var filter03 = new sap.ui.model.Filter({path: "IdSolicitacao", operator: "EQ", value1: IdSolicitacao });
			
			if (NrTransp) {
				oEvent.getParameter("bindingParams").filters.push(filter01,filter02,filter03);
			}
		},

		onBack: function() {
			this.getRouter().navTo("Back");
		},

		onAdd: function() {

			var Bukrs = this.getView().byId("IdBukrs").getValue();
			var WerksO = this.getView().byId("IdWerksO").getValue();
			var IdSolicitacao = this.getView().byId("IdSolicitacao").getValue();
			var IdRota = this.getView().byId("IdRota").getValue();
			var NrTransp = this.getView().byId("IdNrTransp").getValue();

			this.getRouter().navTo("addveic", {
				Bukrs: Bukrs,
				WerksO: WerksO,
				IdSolicitacao: IdSolicitacao,
				IdRota: IdRota,
				NrTransp: NrTransp
			});
		},

		onDelete: function() {

			var oModel = this.getView().getModel();
			var oTable = this.getView().byId("smartTable").getTable();
			var items = oTable._aSelectedPaths;
			var length = items.length;
			var erro = 0;
			var este = this;
			var texto = " ";
			if (items.length < 1) {
				sap.m.MessageBox.error("Nenhuma linha selecionada");
				return;
			} else {
				texto = "Confirma exclusão dos registros selecionados?";
			}

			var dialog = new Dialog({
				title: "Confirmação",
				type: "Message",
				content: new Text({
					text: texto
				}),
				beginButton: new Button({
					text: "Sim",
					press: function() {

						for (var i = 0; i < length; i++) {
							var oEntry = oTable._aSelectedPaths[i];

							oModel.remove(oEntry, {
								method: "DELETE",
								success: function(data) {

									erro = 0;
								},
								error: function(e) {

									erro = 1;
								}
							});
						}
						dialog.close();
						oTable = este.byId("smartTable");
						oTable.getBinding("items").refresh();

						if (erro === 0) {
							sap.m.MessageBox.success("Registros Excluidos Corretamente!");
						} else if (erro === 1) {
							sap.m.MessageBox.error("Registros não foram excluidos - Erro ao chamar o serviço!");
						}

						var smartTable = this.getView().byId("smartTable");
						smartTable.rebindTable("e");

					}
				}),
				endButton: new Button({
					text: "Cancelar",
					press: function() {
						dialog.close();
					}
				}),
				afterClose: function() {
					dialog.destroy();
				}
			});
			dialog.open();

		},

		_bindView: function(sObjectPath) {
			// Set busy indicator during view binding
			var oViewModel = this.getView("transpoView").getModel();
			//this.getView().getModel();

			// If the view was not bound yet its not busy, only if the binding requests data it is set to busy again
			oViewModel.setProperty("/busy", false);

			this.getView().bindElement({
				path: sObjectPath,
				events: {
					change: this._onBindingChange.bind(this),
					dataRequested: function() {
						oViewModel.setProperty("/busy", true);
					},
					dataReceived: function() {
						oViewModel.setProperty("/busy", false);
					}
				}
			});
		},

		_onBindingChange: function() {
			var oView = this.getView(),
				oElementBinding = oView.getElementBinding();

			// No data for the binding
			// if (!oElementBinding.getBoundContext()) {
			// 	sap.m.MessageBox.error("");
			// 	this.getRouter().navTo("Back");
			// 	return;

			// 	this.getRouter().getTargets().display("detailObjectNotFound");
			// 	// if object could not be found, the selection in the master list
			// 	// does not make sense anymore.
			// 	this.getOwnerComponent().oListSelector.clearMasterListSelection();

			// 	return;
			// }

			var sPath = oElementBinding.getPath(),
				oResourceBundle = this.getResourceBundle(),
				oObject = oView.getModel().getObject(sPath),
				sObjectId = oObject.IdSolicitacao,
				sObjectName = oObject.IdSolicitacao,
				oViewModel = this.getView("transpoView").getModel();

			this.getOwnerComponent().oListSelector.selectAListItem(sPath);

			oViewModel.setProperty("/saveAsTileTitle", oResourceBundle.getText("shareSaveTileAppTitle", [sObjectName]));
			oViewModel.setProperty("/shareOnJamTitle", sObjectName);
			oViewModel.setProperty("/shareSendEmailSubject",
				oResourceBundle.getText("shareSendEmailObjectSubject", [sObjectId]));
			oViewModel.setProperty("/shareSendEmailMessage",
				oResourceBundle.getText("shareSendEmailObjectMessage", [sObjectName, sObjectId, location.href]));

			var smartTable = this.getView().byId("smartTable");
			smartTable.rebindTable("e");
		}
	});

});