/*global history */
sap.ui.define([
	"ZPUI_BCMM_COND/ZPUI_BCMM_COND/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/GroupHeaderListItem",
	"sap/ui/Device",
	"ZPUI_BCMM_COND/ZPUI_BCMM_COND/model/formatter",
	"ZPUI_BCMM_COND/ZPUI_BCMM_COND/model/grouper",
	"ZPUI_BCMM_COND/ZPUI_BCMM_COND/model/GroupSortState"
], function(BaseController, JSONModel, History, Filter, FilterOperator, GroupHeaderListItem, Device, formatter, grouper,
	GroupSortState) {
	"use strict";

	return BaseController.extend("ZPUI_BCMM_COND.ZPUI_BCMM_COND.controller.Master", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the master list controller is instantiated. It sets up the event handling for the master/detail communication and other lifecycle tasks.
		 * @public
		 */
		onInit: function() {
			// Control state model
			var oList = this.byId("list"),

				oViewModel = this._createViewModel(),
				// Put down master list's original value for busy indicator delay,
				// so it can be restored later on. Busy handling on the master list is
				// taken care of by the master list itself.
				iOriginalBusyDelay = oList.getBusyIndicatorDelay();

			this._oList = oList;
			// keeps the filter and search state
			this._oListFilterState = {
				aFilter: [],
				aSearch: []
			};
			// var oEventBus = sap.ui.getCore().getEventBus();
			// oEventBus.subscribe("Detail", "selectFirstItemAfter", this.selectFirstItemAfter, this);

			this.setModel(oViewModel, "masterView");
			// Make sure, busy indication is showing immediately so there is no
			// break after the busy indication for loading the view's meta data is
			// ended (see promise 'oWhenMetadataIsLoaded' in AppController)
			oList.attachEventOnce("updateFinished", function() {
				// Restore original busy indicator delay for the list
				oViewModel.setProperty("/delay", iOriginalBusyDelay);
			});

			this.getView().addEventDelegate({
				onBeforeFirstShow: function() {
					this.getOwnerComponent().oListSelector.setBoundMasterList(oList);
				}.bind(this)
			});

			this.getRouter().getRoute("master").attachPatternMatched(this._onMasterMatched, this);
			this.getRouter().attachBypassed(this.onBypassed, this);

		},

		// selectFirstItemAfter: function() {
		// 	var oList = this.getView().byId("list");
		// 	oList.attachEvent("updateFinished", function() {
		// 		//this.oInitialLoadFinishedDeferred.resolve();
		// 		var aItems = oList.getItems();
		// 		if (aItems.length) {
		// 			oList.setSelectedItem(aItems[0], true);
		// 			//Load the detail view in desktop
		// 			this.loadDetailView();
		// 			oList.fireSelect({
		// 				"listItem": aItems[0]
		// 			});
		// 		} else {
		// 			this.getRouter().myNavToWithoutHash({
		// 				currentView: this.getView(),
		// 				targetViewName: "ZPUI_BCMM_COND.view.detailNoObjectsAvailable",
		// 				targetViewType: "XML"
		// 			});
		// 		}
		// 	}, this);
		// },

		// atualizaMaster: function(oControlEvent) {

		// 	var list,
		// 		binding;
		// 	if (oControlEvent.getParameter("reason") === 'Refresh') {
		// 		list = this.getView().byId("list");
		// 		binding = list.getBinding("items");
		// 		binding.refresh(true);
		// 	}
		// },

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		/**
		 * After list data is available, this handler method updates the
		 * master list counter and hides the pull to refresh control, if
		 * necessary.
		 * @param {sap.ui.base.Event} oEvent the update finished event
		 * @public
		 */
		onUpdateFinished: function(oEvent) {
			// update the master list object counter after new data is loaded
			this._updateListItemCount(oEvent.getParameter("total"));
			// hide pull to refresh if necessary
			this.byId("pullToRefresh").hide();

		},

		onSearch: function(oEvent) {
			if (oEvent.getParameters().refreshButtonPressed) {
				this.onRefresh();
				return;
			}

			var sQuery = oEvent.getParameter("query");
			sQuery = parseInt(sQuery);
			var filtro1 = new Filter("IdSolicitacao", FilterOperator.EQ, sQuery);
			//var filtro2 = new Filter("Status", FilterOperator.EQ, "CNDC");
			if (sQuery) {
				this._oListFilterState.aSearch = [filtro1];
			}

			this._applyFilterSearch();

		},

		onRefresh: function() {
			this._oList.getBinding("items").refresh();
		},

		onSelectionChange: function(oEvent) {
			// get the list item, either from the listItem parameter or from the event's source itself (will depend on the device-dependent mode).
			this._showDetail(oEvent.getParameter("listItem") || oEvent.getSource());

		},

		onBypassed: function() {
			this._oList.removeSelections(true);
		},

		createGroupHeader: function(oGroup) {
			return new GroupHeaderListItem({
				title: oGroup.text,
				upperCase: false
			});
		},

		onNavBack: function() {
			var sPreviousHash = History.getInstance().getPreviousHash(),
				oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");

			if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
				history.go(-1);
			} else {
				oCrossAppNavigator.toExternal({
					target: {
						shellHash: "#Shell-home"
					}
				});
			}
		},

		_createViewModel: function() {
			return new JSONModel({
				isFilterBarVisible: false,
				filterBarLabel: "",
				delay: 0,
				title: this.getResourceBundle().getText("masterTitleCount", [0]),
				noDataText: this.getResourceBundle().getText("masterListNoDataText"),
				sortBy: "IdSolicitacao",
				groupBy: "None"
			});
		},

		_onMasterMatched: function() {
			this.getOwnerComponent().oListSelector.oWhenListLoadingIsDone.then(
				function(mParams) {
					if (mParams.list.getMode() === "None") {
						return;
					}
					var IdSolicitacao = mParams.firstListitem.getBindingContext().getProperty("IdSolicitacao");
					var Bukrs = mParams.firstListitem.getBindingContext().getProperty("Bukrs");
					var WerksO = mParams.firstListitem.getBindingContext().getProperty("WerksO");

					this.getRouter().navTo("object", {
						Bukrs: Bukrs,
						IdSolicitacao: IdSolicitacao,
						WerksO: WerksO
					}, true);
				}.bind(this),
				function(mParams) {
					if (mParams.error) {
						return;
					}
					this.getRouter().getTargets().display("detailNoObjectsAvailable");
				}.bind(this)
			);

		},

		_showDetail: function(oItem) {
			var bReplace = !Device.system.phone;
			var Bukrs = oItem.getBindingContext().getProperty("Bukrs");
			var IdSolicitacao = oItem.getBindingContext().getProperty("IdSolicitacao");
			var WerksO = oItem.getBindingContext().getProperty("WerksO");

			this.getRouter().navTo("object", {
				Bukrs: Bukrs,
				IdSolicitacao: IdSolicitacao,
				WerksO: WerksO

			}, bReplace);
		},

		/**
		 * Sets the item count on the master list header
		 * @param {integer} iTotalItems the total number of items in the list
		 * @private
		 */
		_updateListItemCount: function(iTotalItems) {
			var sTitle;
			// only update the counter if the length is final
			if (this._oList.getBinding("items").isLengthFinal()) {
				sTitle = this.getResourceBundle().getText("masterTitleCount", [iTotalItems]);
				this.getModel("masterView").setProperty("/title", sTitle);
			}
		},

		/**
		 * Internal helper method to apply both filter and search state together on the list binding
		 * @private
		 */
		_applyFilterSearch: function() {
			var aFilters = this._oListFilterState.aSearch.concat(this._oListFilterState.aFilter),
				oViewModel = this.getModel("masterView");
			this._oList.getBinding("items").filter(aFilters, "Application");
			// changes the noDataText of the list in case there are no filter results
			if (aFilters.length !== 0) {
				oViewModel.setProperty("/noDataText", this.getResourceBundle().getText("masterListNoDataWithFilterOrSearchText"));
			} else if (this._oListFilterState.aSearch.length > 0) {
				// only reset the no data text to default when no new search was triggered
				oViewModel.setProperty("/noDataText", this.getResourceBundle().getText("masterListNoDataText"));
			}
		},

		/**
		 * Internal helper method to apply both group and sort state together on the list binding
		 * @param {sap.ui.model.Sorter[]} aSorters an array of sorters
		 * @private
		 */
		_applyGroupSort: function(aSorters) {
			this._oList.getBinding("items").sort(aSorters);
		},

		/**
		 * Internal helper method that sets the filter bar visibility property and the label's caption to be shown
		 * @param {string} sFilterBarText the selected filter value
		 * @private
		 */
		_updateFilterBar: function(sFilterBarText) {
			var oViewModel = this.getModel("masterView");
			oViewModel.setProperty("/isFilterBarVisible", (this._oListFilterState.aFilter.length > 0));
			oViewModel.setProperty("/filterBarLabel", this.getResourceBundle().getText("masterFilterBarText", [sFilterBarText]));
		}
	});

});