sap.ui.define([
"ZPUI_BCMM_COND/ZPUI_BCMM_COND/controller/BaseController",
"sap/ui/model/json/JSONModel",
	"ZPUI_BCMM_COND/ZPUI_BCMM_COND/model/formatter"
], function(BaseController, JSONModel, formatter) {
	"use strict";

	return BaseController.extend("ZPUI_BCMM_COND.ZPUI_BCMM_COND.controller.Veiculo", {

	onInit: function() {
			// var oViewModel = new JSONModel({
			// 	busy: false,
			// 	delay: 0
			// });

			this.getRouter().getRoute("addveic").attachPatternMatched(this._onObjectMatched, this);

			//this.setModel(oViewModel, "detailView");

			//this.getOwnerComponent().getModel().metadataLoaded().then(this._onMetadataLoaded.bind(this));
		},

		_onObjectMatched: function(oEvent) {
			this.getView().byId("Bukrs").setValue(oEvent.getParameter("arguments").Bukrs);
			this.getView().byId("IdSolicitacao").setValue(oEvent.getParameter("arguments").IdSolicitacao);
			this.getView().byId("WerksO").setValue(oEvent.getParameter("arguments").WerksO);
			this.getView().byId("IdRota").setValue(oEvent.getParameter("arguments").IdRota);
			this.getView().byId("NrTransp").setValue(oEvent.getParameter("arguments").NrTransp);

			
		},
		
		OnSave: function() {

			var oModel = this.getView().getModel();
			var key = "";
			var oParameters = {};
			var este = this;

			oParameters.Bukrs = this.getView().byId("Bukrs").getValue();
			oParameters.WerksO = this.getView().byId("WerksO").getValue();
			oParameters.IdSolicitacao = parseInt(this.getView().byId("IdSolicitacao").getValue());
			oParameters.IdRota = parseInt(this.getView().byId("IdRota").getValue());
			oParameters.NrTransp = this.getView().byId("NrTransp").getValue();
			oParameters.TpVeiculo = this.getView().byId("IdTpVeiculo").getValue();
			
			if (!oParameters.TpVeiculo ){
			sap.m.MessageBox.show("Campo Tipo de veículo obrigatório");
			return;
			}
			
			oParameters.TpVeiculo = oParameters.TpVeiculo.replace(/ /g, "%20");
			
			var oModel2 = new sap.ui.model.json.JSONModel();
			var serviceUrl = "/sap/opu/odata/sap/ZGWCBMM_CONTRATACAO_FRETE_SRV/ZET_CBMM_CF_VEIC_HSet/$count?$filter=Matnr eq '" + oParameters.TpVeiculo + "'";

			oModel2.loadData(serviceUrl, null, false, "GET", false, false, null);
			var oInd = oModel2.getData();

			if (oInd !== 1) {
				sap.m.MessageToast.show("Veículo inválido, favor selecionar um veículo válido.");
				return;
			}
			
			
			key = "/ZET_CBMM_CF_VEICULOSet(Bukrs='" + oParameters.Bukrs + "',WerksO='" + oParameters.WerksO + "',IdSolicitacao=" + oParameters
				.IdSolicitacao + ",IdRota=" + oParameters.IdRota + ",NrTransp='" + oParameters.NrTransp + "',TpVeiculo='" + oParameters.TpVeiculo + "')";

			oModel.update(key, oParameters, {
				success: function(oData, oResponse) {
					sap.m.MessageBox.success("Veiculo cadastrado com sucesso", {
						actions: ["OK", sap.m.MessageBox.Action.CLOSE],
						onClose: function(sAction) {
							este.getView().byId("IdTpVeiculo").setValue(null);
							este.getRouter().navTo("backtranspo");
						}

					});
				
				},

				error: function(e) {
					sap.m.MessageBox.error("Não foi possível inserir o veículo");
				}
			});

		},

		onCanc: function() {
		// voltar para tela anterior
		this.getRouter().navTo("backtranspo");
		},

		onTpVeiculo: function(oEvent) {
			var sInputValue = oEvent.getSource().getValue();
			this.inputId = oEvent.getSource().getId();
			// create value help dialog
			if (!this._valueHelpDialog2) {
				this._valueHelpDialog2 = sap.ui.xmlfragment("ZPUI_BCMM_COND.ZPUI_BCMM_COND.view.Veic", this);
				this.getView().addDependent(this._valueHelpDialog2);
			}
			// open value help dialog filtered by the input value
			this._valueHelpDialog2.open(sInputValue);
		},

		_handleValueHelpClose: function(evt) {
			var oSelectedItem = evt.getParameter("selectedItem");

			this._valueHelpDialog1 = null;
			this._valueHelpDialog4 = null;
			this._valueHelpDialog6 = null;

			if (oSelectedItem) {
				var productInput = this.getView().byId(this.inputId);
				productInput.setValue(oSelectedItem.getTitle());
			}
			evt.getSource().getBinding("items").filter([]);
			this.getView().byId(this.inputId).setValueState("None");
		},

		_handleValueHelpVeic: function(oEvent) {
			var sValue = oEvent.getParameter("value");

			if (!sValue) {
				sValue = " ";
			}

			var sFilter = sValue;

			var oFilter = oFilter = new sap.ui.model.Filter("Matnr", sap.ui.model.FilterOperator.EQ, sFilter);
			oEvent.getSource().getBinding("items").filter([oFilter]);

			// var sValue = oEvent.getParameter("value");
			// var oFilter = new sap.ui.model.Filter("Aprovador",
			// 	sap.ui.model.FilterOperator.Contains, sValue);
			// oEvent.getSource().getBinding("items").filter([oFilter]);
		}

	});
});