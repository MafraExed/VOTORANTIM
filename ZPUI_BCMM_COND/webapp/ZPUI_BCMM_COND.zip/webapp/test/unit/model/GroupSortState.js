/*global QUnit*/

sap.ui.define([
	"ZPUI_BCMM_COND/ZPUI_BCMM_COND/model/GroupSortState",
	"sap/ui/model/json/JSONModel"
], function (GroupSortState, JSONModel) {
	"use strict";

	QUnit.module("GroupSortState - grouping and sorting", {
		beforeEach: function () {
			this.oModel = new JSONModel({});
			// System under test
			this.oGroupSortState = new GroupSortState(this.oModel, function() {});
		}
	});

	QUnit.test("Should always return a sorter when sorting", function (assert) {
		// Act + Assert
		assert.strictEqual(this.oGroupSortState.sort("IdSolicitacao").length, 1, "The sorting by IdSolicitacao returned a sorter");
		assert.strictEqual(this.oGroupSortState.sort("Bukrs").length, 1, "The sorting by Bukrs returned a sorter");
	});

	QUnit.test("Should return a grouper when grouping", function (assert) {
		// Act + Assert
		assert.strictEqual(this.oGroupSortState.group("IdSolicitacao").length, 1, "The group by IdSolicitacao returned a sorter");
		assert.strictEqual(this.oGroupSortState.group("None").length, 0, "The sorting by None returned no sorter");
	});


	QUnit.test("Should set the sorting to IdSolicitacao if the user groupes by IdSolicitacao", function (assert) {
		// Act + Assert
		this.oGroupSortState.group("IdSolicitacao");
		assert.strictEqual(this.oModel.getProperty("/sortBy"), "IdSolicitacao", "The sorting is the same as the grouping");
	});

	QUnit.test("Should set the grouping to None if the user sorts by Bukrs and there was a grouping before", function (assert) {
		// Arrange
		this.oModel.setProperty("/groupBy", "IdSolicitacao");

		this.oGroupSortState.sort("Bukrs");

		// Assert
		assert.strictEqual(this.oModel.getProperty("/groupBy"), "None", "The grouping got reset");
	});
});