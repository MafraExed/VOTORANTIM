/*global QUnit*/

jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
	"sap/ui/test/Opa5",
	"ZPUI_BCMM_COND/ZPUI_BCMM_COND/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"ZPUI_BCMM_COND/ZPUI_BCMM_COND/test/integration/pages/App",
	"ZPUI_BCMM_COND/ZPUI_BCMM_COND/test/integration/pages/Browser",
	"ZPUI_BCMM_COND/ZPUI_BCMM_COND/test/integration/pages/Master",
	"ZPUI_BCMM_COND/ZPUI_BCMM_COND/test/integration/pages/Detail",
	"ZPUI_BCMM_COND/ZPUI_BCMM_COND/test/integration/pages/NotFound"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "ZPUI_BCMM_COND.ZPUI_BCMM_COND.view."
	});

	sap.ui.require([
		"ZPUI_BCMM_COND/ZPUI_BCMM_COND/test/integration/NavigationJourneyPhone",
		"ZPUI_BCMM_COND/ZPUI_BCMM_COND/test/integration/NotFoundJourneyPhone",
		"ZPUI_BCMM_COND/ZPUI_BCMM_COND/test/integration/BusyJourneyPhone"
	], function () {
		QUnit.start();
	});
});